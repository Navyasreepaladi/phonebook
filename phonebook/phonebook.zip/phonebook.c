#include<stdio.h>

#include<conio.h>

#include<string.h>

#include<stdlib.h>

#include<windows.h>

struct person

{

    char name[35];

    char address[50];

    char father_name[35];

    char mother_name[30];

    long int mble_no;

    char sex[8];

    char mail[100];

    char citision_no[20];

    char imp_event[100];

     int year,yearc,mon,monc,leapyear,cen,cenc1,cenc2,noyear,date,weekc,a,b,c,d,e,f1,g,h,n,k,l,m,date1;



    }p;

//struct person p;

void menu();

void got();

void start();

void back();

void addrecord();

void listrecord();

void modifyrecord();

void deleterecord();

void searchrecord();

void imp_date();

void get_date();

int main()

{

    system("color 2f");

    start();

    return 0;

}

void back()

{

    start();

}

void start()

{

    menu();

}

void menu()

{

system("cls");

printf("\t\t**********MY PHONEBOOK*************");



printf("\n\n\t\tMENU\t\t\n\n");

printf("\t1.ADD NEW CONTACT   \t2.LIST OF ALL CONTACTS  \t3.MODIFY CONTACTS \n\t4.SEARCH CONTACTS \t5.DELETE CONTACTS   \t\t6.EXIT \n\t7.ADD IMPORTANT DATES \t8.IMPORTANT DATES");



switch(getch())

{

    case '1': addrecord();

    break;

    case '2': listrecord();

    break;

    case '3': modifyrecord();

    break;

    case '4': searchrecord();

    break;

    case '5': deleterecord();

    break;

    case '6': exit(0);

    break;

    case '7': get_date();

    break;

    case '8': imp_date();

    break;

    default:

                system("cls");

                printf("\nEnter 1 to 8 only");

                printf("\n Enter any key");

                getch();



menu();

}

}

        void addrecord()

{ 

	system("color 1f");

        system("cls");

        FILE *f;

        struct person p;

        f=fopen("project","ab+");

        printf("\n Enter name: ");

        got(p.name);

        printf("\nEnter the address: ");

        got(p.address);

        printf("\nEnter father name: ");

        got(p.father_name);

        printf("\nEnter mother name: ");

        got(p.mother_name);

        printf("\nEnter phone no.:");

        scanf("%ld",&p.mble_no);

        printf("Enter sex:");

        got(p.sex);

        printf("\nEnter e-mail:");

        got(p.mail);

        printf("\nEnter citizen no:");

        got(p.citision_no);

        fwrite(&p,sizeof(p),1,f);



      fflush(stdin);

system("cls");

        printf("\nrecord saved");

fclose(f);



    printf("\n\nEnter any key");



	 getch();

    system("cls");

    menu();

}

void listrecord()

{

    system("color 5f");

    struct person p;

    FILE *f;

f=fopen("project","rb");

if(f==NULL)

{

printf("\nfile opening error in listing :");



exit(1);

}

while(fread(&p,sizeof(p),1,f)==1)

{

     printf("\n\n\n YOUR RECORD IS\n\n ");

        printf("\nName=%s\nAdress=%s\nFather name=%s\nMother name=%s\nMobile no=%ld\nSex=%s\nE-mail=%s\nCitizen no=%s",p.name,p.address,p.father_name,p.mother_name,p.mble_no,p.sex,p.mail,p.citision_no);



	 getch();

	 system("cls");

}

fclose(f);

 printf("\n Enter any key");

 getch();

    system("cls");

menu();

}

void searchrecord()

{

 system("color 3f");

    struct person p;

FILE *f;

char name[100];



f=fopen("project","rb");

if(f==NULL)

{

    printf("\n error in opening\a\a\a\a");

    exit(1);



}

printf("\nEnter name of person to search\n");

got(name);

while(fread(&p,sizeof(p),1,f)==1)

{

    if(strcmp(p.name,name)==0)

    {

        printf("\n\tDetail Information About %s",name);

        printf("\nName:%s\naddress:%s\nFather name:%s\nMother name:%s\nMobile no:%ld\nsex:%s\nE-mail:%s\nCitizen no:%s",p.name,p.address,p.father_name,p.mother_name,p.mble_no,p.sex,p.mail,p.citision_no);

    }

        //else

        //printf("file not found");

}



 fclose(f);

  printf("\n Enter any key");



	 getch();

    system("cls");

menu();

}

void deleterecord()

{

    system("color 4f");

    struct person p;

    FILE *f,*ft;

	int flag;

	char name[100];

	f=fopen("project","rb");

	if(f==NULL)

		{



			printf("CONTACT'S DATA NOT ADDED YET.");



		}

	else

	{

		ft=fopen("temp","wb+");

		if(ft==NULL)



            printf("file opening error");

		else



        {





		printf("\nEnter CONTACT'S NAME:\n");

		got(name);



		fflush(stdin);

		while(fread(&p,sizeof(p),1,f)==1)

		{

			if(strcmp(p.name,name)!=0)

				fwrite(&p,sizeof(p),1,ft);

			if(strcmp(p.name,name)==0)

                flag=1;

		}

	fclose(f);

	fclose(ft);

	if(flag!=1)

	{

		printf("NO CONTACT'S RECORD TO DELETE.");

		remove("temp.txt");

	}

		else

		{

			remove("project");

			rename("temp.txt","project");

			printf("RECORD DELETED SUCCESSFULLY.");



		}

	}

}

 printf("\n Enter any key");



	 getch();

    system("cls");

menu();

}



void modifyrecord()

{

    int c;

    FILE *f;

    int flag=0;

    struct person p,s;

	char  name[50];

	f=fopen("project","rb+");

	if(f==NULL)

		{



			printf("CONTACT'S DATA NOT ADDED YET.");

			exit(1);





		}

	else

	{

	    system("cls");

		printf("\nEnter CONTACT'S NAME TO MODIFY:\n");

            got(name);

            while(fread(&p,sizeof(p),1,f)==1)

            {

                if(strcmp(name,p.name)==0)

                {







                    printf("\n Enter name:");

                    got(s.name);

                    printf("\nEnter the address:");

                    got(s.address);

                    printf("\nEnter father name:");

                    got(s.father_name);

                    printf("\nEnter mother name:");

                    got(s.mother_name);

                    printf("\nEnter phone no:");

                    scanf("%ld",&s.mble_no);

                    printf("\nEnter sex:");

                    got(s.sex);

                    printf("\nEnter e-mail:");

                    got(s.mail);

                    printf("\nEnter citizen no\n");

                    got(s.citision_no);

                    fseek(f,-sizeof(p),SEEK_CUR);

                    fwrite(&s,sizeof(p),1,f);

                    flag=1;

                    break;

		}

                fflush(stdin);





            }

            if(flag==1)

            {

                printf("\n your data id modified");



            }

            else

            {

                    printf(" \n data is not found");



            }

            fclose(f);

	}

	 printf("\n Enter any key");

	 getch();

    system("cls");

	menu();



}

void got(char *name)

{



   int i=0,j;

    char c,ch;

    do

    {

        c=getch();

                if(c!=8&&c!=13)

                {

                    *(name+i)=c;

                        putch(c);

                        i++;

                }

                if(c==8)

                {

                    if(i>0)

                    {

                        i--;

                    }

                    system("cls");

                    for(j=0;j<i;j++)

                    {

                        ch=*(name+j);

                        putch(ch);



                    }



                }

    }while(c!=13);

      *(name+i)='\0';

}

void imp_date()

{

    system("cls");

 system("color 3f");

    struct person p;

FILE *f;

int mon_i;

int year_i;



f=fopen("project","rb");

if(f==NULL)

{

    printf("\n error in opening\a\a\a\a");

    exit(1);



}

printf("\nEnter month\n");

scanf("%d",&mon_i);

printf("\nEnter year\n");

scanf("%d",&year_i);

while(fread(&p,sizeof(p),1,f)==1)

{

    if(p.mon==mon_i&&p.year==year_i)

    {

        printf("\n\tEVENTS IN THE MONTH %d IS",mon_i);

        printf("\nMONTH:%d\nYEAR:%d\nDATE:%d\nEVENT:%s\n",p.mon,p.year,p.date1,p.imp_event);



 }

       // else

        //printf("file not found");



}



int year,yearc,mon,monc,leapyear,cen,cenc1,cenc2,noyear,date,weekc,a,b,c,d,e,f1,g,h,n,k,l,m,date1;

printf("\n **********CALENDAR OF THE MONTH IS********** \n");

date=1;

if(mon_i==1||mon_i==10)

monc=1;

else if(mon_i==2||mon_i==3||mon_i==11)

monc=4;

else if(mon_i==4||mon_i==7)

monc=0;

else if(mon_i==5)

monc=2;

else if(mon_i==6)

monc=5;

else if(mon_i==9||mon_i==12)

monc=6;

else if(mon_i==8)

monc=3;

noyear=year_i%100;

leapyear=noyear/4;



cen=year_i+100;

cen=cen/100;

cenc1=cen%4;

if(cenc1==1)

cenc2=6;

if(cenc1==2)

cenc2=4;

if(cenc1==3)

cenc2=2;

if(cenc1==0)

cenc2=0;

weekc=date+monc+noyear+cenc2+leapyear;

weekc=weekc%7;

printf("\n\tsun\tmon\ttue\twed\tthu\tfri\tsat\n");

a=7-weekc+1;

if(a==6)

printf("\t");

if(a==5)

printf("\t\t");

if(a==4)

printf("\t\t\t");

if(a==3)

printf("\t\t\t\t");

if(a==2)

printf("\t\t\t\t\t");

if(a==8)

printf("\t\t\t\t\t\t");

if(a==8)

a=1;

for(b=1;b<=a;b++)

{

printf("\t%d",b);

}

printf("\n");

c=a+7;

for(d=a+1;d<=c;d++)

{

printf("\t%d",d);

}

printf("\n");

e=c+7;

for(f1=c+1;f1<=e;f1++)

{

printf("\t%d",f1);

}

printf("\n");

g=e+7;

for(h=e+1;h<=g;h++)

{



printf("\t%d",h);

}

printf("\n");

l=g+7;

for(m=g+1;m<=l;m++)

{

if((mon_i==1||mon_i==3||mon_i==5||mon_i==7||mon_i==8||mon_i==10||mon_i==12)&&m<=31)

printf("\t%d",m);

else if((mon_i==4||mon_i==6||mon_i==9||mon_i==11)&&m<=30)

printf("\t%d",m);

else if(mon_i==2&&m<=28)

printf("\t%d",m);

}

printf("\n");



if(mon_i==1||mon_i==3||mon_i==5||mon_i==7||mon_i==8||mon_i==10||mon_i==12)

k=31;

else if(mon_i==4||mon_i==6||mon_i==9||mon_i==11)



k=30;

else

k=28;





for(n=l+1;n<=k;n++)

{

printf("\t%d",n);

}

}

fclose(f);

     

// calendar

 void get_date()

{

 system("color 8f");

     

        FILE *f;

        struct person p;

        f=fopen("project","ab+");

        printf("\n Enter Date: ");

       scanf("%d",&p.date1);

        printf("\nEnter month");

       scanf("%d",&p.mon);

        printf("\nEnter year ");

       scanf("%d",&p.year);

        printf("\nEnter event ");

        got(p.imp_event);



        fwrite(&p,sizeof(p),1,f);



      fflush(stdin);

        printf("\nDate saved");



fclose(f);



    printf("\n\nEnter any key");



	 getch();

    system("cls");

    menu();

}













